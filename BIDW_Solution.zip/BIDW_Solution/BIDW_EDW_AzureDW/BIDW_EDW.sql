/****** Object:  Table [dbo].[DimCreditReason]    Script Date: 4/18/2017 3:07:24 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimCreditReason]
(
	[CreditReasonDimKey] [int] NOT NULL,
	[CreditReasonCode] [nvarchar](10) NOT NULL,
	[CreditReasonType] [nvarchar](10) NOT NULL,
	[CreditReasonDescription] [nvarchar](50) NOT NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimCustomer]    Script Date: 4/18/2017 3:07:24 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimCustomer]
(
	[CustomerDimKey] [int] NOT NULL,
	[ChainNumber] [int] NOT NULL,
	[CustomerNumber] [int] NOT NULL,
	[SubCustomerNumber] [int] NULL,
	[CustomerCode] [varchar](20) NOT NULL,
	[CustomerName] [nvarchar](100) NOT NULL,
	[DistCenterNumber] [varchar](10) NULL,
	[BusUnitNumber] [varchar](10) NULL,
	[DefaultRouteNumber] [int] NULL,
	[SalesRepNumber] [int] NOT NULL,
	[SalesRepName] [nvarchar](100) NULL,
	[SalesRepAddressLine1] [nvarchar](50) NULL,
	[SalesRepCity] [nvarchar](30) NULL,
	[SalesRepState] [nvarchar](3) NULL,
	[SalesRepZip] [nvarchar](10) NULL,
	[ClassOfTrade] [nvarchar](50) NULL,
	[CustomerInactiveFlag] [int] NOT NULL,
	[ShipToName] [nvarchar](100) NULL,
	[ShipToAdressLine1] [nvarchar](50) NULL,
	[ShipToAddressLine2] [nvarchar](30) NULL,
	[ShipToCity] [nvarchar](30) NULL,
	[ShipToState] [nvarchar](3) NULL,
	[ShipToZip] [nvarchar](10) NULL,
	[BillToName] [nvarchar](100) NULL,
	[BillToAdressLine1] [nvarchar](50) NULL,
	[BillToAddressLine2] [nvarchar](30) NULL,
	[BillToCity] [nvarchar](30) NULL,
	[BillToState] [nvarchar](3) NULL,
	[BillToZip] [nvarchar](10) NULL,
	[Parent] [nvarchar](50) NULL,
	[Division] [nvarchar](50) NULL,
	[Owner] [nvarchar](50) NULL,
	[DistributionFormat] [nvarchar](50) NULL,
	[TradeChannel] [nvarchar](50) NULL,
	[SpecialBillingCode] [tinyint] NULL,
	[CUSCRTUSR] [nvarchar](10) NULL,
	[CUSCRTDTE] [int] NULL,
	[CUSCRTTIM] [int] NULL,
	[SrcUpdatedBy] [nvarchar](10) NULL,
	[ScrUpdatedDate] [int] NULL,
	[CUSCHGTIM] [int] NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL,
	[SourceSystem] [varchar](4) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimDate]    Script Date: 4/18/2017 3:07:24 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimDate]
(
	[DateDimKey] [int] NOT NULL,
	[FullDate] [date] NULL,
	[DateName] [nchar](10) NOT NULL,
	[DayOfWeek] [tinyint] NOT NULL,
	[DayNameOfWeek] [nvarchar](10) NOT NULL,
	[DayOfMonth] [tinyint] NOT NULL,
	[DayOfYear] [smallint] NOT NULL,
	[WeekdayWeekend] [nchar](10) NOT NULL,
	[WeekOfYear] [tinyint] NOT NULL,
	[WeekEndingDate] [date] NOT NULL,
	[WeekEndingName] [varchar](30) NOT NULL,
	[MonthName] [nvarchar](10) NOT NULL,
	[MonthOfYear] [tinyint] NOT NULL,
	[IsLastDayOfMonth] [nchar](1) NOT NULL,
	[CalendarQuarter] [tinyint] NOT NULL,
	[CalendarYear] [smallint] NOT NULL,
	[CalendarYearMonth] [varchar](10) NOT NULL,
	[CalendarYearQtr] [varchar](10) NOT NULL,
	[MonthNameEnglish] [varchar](20) NULL,
	[QuarterNameEnglish] [varchar](9) NULL,
	[FiscalMonthOfYear] [tinyint] NULL,
	[FiscalQuarter] [tinyint] NULL,
	[FiscalYear] [int] NULL,
	[FiscalYearMonth] [nchar](10) NULL,
	[FiscalYearQtr] [nchar](10) NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimDriver]    Script Date: 4/18/2017 3:07:24 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimDriver]
(
	[DriverDimKey] [int] NOT NULL,
	[ChainNumber] [int] NOT NULL,
	[DriverNumber] [int] NOT NULL,
	[SubCustomerNumber] [int] NOT NULL,
	[DriverCode] [varchar](20) NOT NULL,
	[DriverName] [nvarchar](50) NOT NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimItem]    Script Date: 4/18/2017 3:07:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimItem]
(
	[ItemDimKey] [int] NOT NULL,
	[IMITM] [int] NULL,
	[ItemNumber] [varchar](20) NULL,
	[ItemDesc] [nvarchar](100) NULL,
	[IMSRTX] [nvarchar](50) NULL,
	[IMALN] [nvarchar](50) NULL,
	[UPC] [nvarchar](20) NULL,
	[BrandCode] [varchar](3) NULL,
	[BrandName] [nvarchar](50) NULL,
	[CategoryCode] [varchar](3) NULL,
	[CategoryName] [nvarchar](50) NULL,
	[PointsFactor] [decimal](9, 5) NULL,
	[CaseFactor] [decimal](9, 2) NULL,
	[GrossLBFactor] [decimal](18, 5) NULL,
	[PalletFactor] [decimal](18, 5) NULL,
	[PCAT2Code] [varchar](3) NULL,
	[PCAT2] [nvarchar](50) NULL,
	[SubBrand] [nvarchar](50) NULL,
	[ProductClass] [nvarchar](50) NULL,
	[Sub-CategoryName] [nvarchar](50) NULL,
	[SegmentName] [nvarchar](50) NULL,
	[Brand2] [nvarchar](50) NULL,
	[FatLevel] [nvarchar](50) NULL,
	[Style] [nvarchar](50) NULL,
	[Flavor] [nvarchar](50) NULL,
	[PackageType] [nvarchar](50) NULL,
	[ProductSizeByOunce] [nvarchar](50) NULL,
	[ContainerType] [nvarchar](50) NULL,
	[SellingUnits] [nvarchar](50) NULL,
	[ManufacturingProcess] [nvarchar](50) NULL,
	[Pre-PackagedUnits] [nvarchar](50) NULL,
	[ProductBrand] [nvarchar](50) NULL,
	[ProductOrigin] [nvarchar](1) NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimRoute]    Script Date: 4/18/2017 3:07:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimRoute]
(
	[RouteDimKey] [int] NOT NULL,
	[RouteNumber] [varchar](10) NOT NULL,
	[RouteName] [nvarchar](50) NULL,
	[PrimaryDriverNumber] [int] NULL,
	[BusUnitNumber] [int] NULL,
	[BusUnitName] [nvarchar](50) NULL,
	[BusUnitCity] [nvarchar](50) NULL,
	[BusUnitState] [nvarchar](3) NULL,
	[DistCenterNumber] [int] NULL,
	[DistCenterName] [nvarchar](50) NULL,
	[DistCenterCity] [nvarchar](50) NULL,
	[DistCenterState] [nvarchar](3) NULL,
	[DistCenterZip] [nvarchar](10) NULL,
	[RouteStatus] [nvarchar](10) NULL,
	[RouteClassCode] [int] NULL,
	[RouteClassDesc] [nvarchar](30) NULL,
	[RTECRTUSR] [nvarchar](10) NULL,
	[RTECRTDTE] [decimal](8, 0) NULL,
	[RTECRTTIM] [decimal](6, 0) NULL,
	[SrcUpdatedBy] [nvarchar](10) NULL,
	[ScrUpdatedDate] [int] NULL,
	[RTECHGTIM] [decimal](6, 0) NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL,
	[SourceSystem] [varchar](4) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[DimSubRoute]    Script Date: 4/18/2017 3:07:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimSubRoute]
(
	[SubRouteDimKey] [int] NOT NULL,
	[SubRouteNumber] [int] NOT NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO
/****** Object:  Table [dbo].[FactSales]    Script Date: 4/18/2017 3:07:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactSales]
(
	[SalesNumber] [bigint] NOT NULL,
	[SalesSeq] [int] NOT NULL,
	[SalesDetailTypeCode] [nvarchar](2) NOT NULL,
	[SalesTypeCode] [nvarchar](2) NOT NULL,
	[TicketNumber] [bigint] NULL,
	[OrderNumber] [bigint] NOT NULL,
	[OrderType] [nvarchar](2) NOT NULL,
	[SalesDeliveryDate] [int] NOT NULL,
	[GLDate] [int] NOT NULL,
	[LoadDate] [int] NULL,
	[CustomerDimKey] [int] NOT NULL,
	[ItemDimKey] [int] NOT NULL,
	[DriverDimKey] [int] NOT NULL,
	[CreditReasonDimKey] [int] NOT NULL,
	[RouteDimKey] [int] NOT NULL,
	[SubRouteDimKey] [int] NOT NULL,
	[Units] [decimal](9, 2) NULL,
	[UnitPrice] [money] NULL,
	[SalesAmount] [money] NULL,
	[DiscountAmount] [money] NULL,
	[UnitDiscount] [money] NULL,
	[DistCenterNumber] [int] NULL,
	[PointsFactor] [decimal](9, 5) NULL,
	[CaseFactor] [decimal](9, 2) NULL,
	[UnitCost] [money] NULL,
	[GrossLB] [decimal](11, 5) NULL,
	[RebateAmount] [money] NULL,
	[InsertAuditKey] [int] NOT NULL,
	[UpdateAuditKey] [int] NOT NULL,
	[ETLDateInserted] [datetime2](7) NOT NULL,
	[SourceSystem] [varchar](4) NOT NULL,
	[SLDCHGDTE] [int] NULL,
	[SDUPMJ] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

GO

/****** Object:  View [dbo].[Credit Reason]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Credit Reason] AS


SELECT [CreditReasonDimKey]			AS [Credit Reason Dim Key]		
      ,[CreditReasonCode]			AS   [Credit Reason Code]
      ,[CreditReasonType]			AS   [Credit Reason Type]
      ,[CreditReasonDescription]	AS   [Credit Reason Description]
      ,[ETLDateInserted]			AS   [ETLDateInserted]
  FROM [dbo].[DimCreditReason]

GO
/****** Object:  View [dbo].[Customer]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Customer] AS




SELECT [CustomerDimKey]			AS [Customer Dim Key]		
      ,[ChainNumber]			AS [Chain Number]
      ,[CustomerNumber]			AS [Customer Number]      
      ,[CustomerCode]			AS [Customer Code]
      ,[CustomerName]			AS [Customer Name]
	  ,CAST([ChainNumber] as varchar(10)) + ' ' + [CustomerName] AS [Customer Number Name]
      ,[DistCenterNumber]		AS [Dist Center Number]
      ,[BusUnitNumber]			AS [Bus Unit Number]
      ,[DefaultRouteNumber]		AS [Default Route Number]
      ,[SalesRepNumber]			AS [Sales Rep Number]
      ,[SalesRepName]			AS [Sales Rep Name]
	  ,CAST([SalesRepNumber] as varchar(10)) + ' - ' + [SalesRepName] AS [Sales Rep]
      ,[SalesRepAddressLine1]	AS [Sales Rep Address Line1]
      ,[SalesRepCity]			AS [Sales Rep City]
      ,[SalesRepState]			AS [Sales Rep State]
      ,[SalesRepZip]			AS [Sales Rep Zip]
      ,[ClassOfTrade]			AS [Class of Trade]
      ,[CustomerInactiveFlag]	AS [Customer Inactive Flag]
      ,[ShipToName]				AS [Ship To Name]
      ,[ShipToAdressLine1]		AS [Ship To Adress Line1]
      ,[ShipToAddressLine2]		AS [Ship To Address Line2]
      ,[ShipToCity]				AS [Ship To City]
      ,[ShipToState]			AS [Ship To State]
      ,[ShipToZip]				AS [Ship To Zip]
      ,[BillToName]				AS [Bill To Name]
      ,[BillToAdressLine1]		AS [Bill To Adress Line1]
      ,[BillToAddressLine2]		AS [Bill To Address Line2]
      ,[BillToCity]				AS [Bill To City]
      ,[BillToState]			AS [Bill To State]
      ,[BillToZip]				AS [Bill To Zip]
      ,[Parent]					AS [Parent]
      ,[Division]				AS [Division]
      ,[Owner]					AS [Owner]
      ,[DistributionFormat]		AS [Distribution Format]
      ,[TradeChannel]			AS [Trade Channel]
      ,[SpecialBillingCode]		AS [Special Billing Code]
      ,[SrcUpdatedBy]			AS [SrcUpdatedBy]
      ,[ScrUpdatedDate]			AS [ScrUpdatedDate]
      ,[ETLDateInserted]		AS [ETLDateInserted]
      ,[SourceSystem]			AS [SourceSystem]
  FROM [dbo].[DimCustomer]

GO
/****** Object:  View [dbo].[Date]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [dbo].[Date] AS 
SELECT [DateDimKey] AS [Date Dim Key]
, [FullDate] AS [Full Date]
, [DateName] AS [Date Name]
, [DayOfWeek] AS [Day Of Week]
, [DayNameOfWeek] AS [Day Name Of Week]
, [DayOfMonth] AS [Day Of Month]
, [DayOfYear] AS [Day Of Year]
, [WeekdayWeekend] AS [Weekday Weekend]
, [WeekOfYear] AS [Week Of Year]
, [WeekEndingName] AS [Week Ending Name]
, [MonthName] AS [Month Name]
, [MonthOfYear] AS [Month Of Year]
, [IsLastDayOfMonth] AS [Is Last Day Of Month]
, [CalendarQuarter] AS [Calendar Qtr Of Year]
, [CalendarYear] AS [Calendar Year]
, [CalendarYearMonth] AS [Calendar Year Month]
, [CalendarYearQtr] AS [Calendar Year Qtr]
, [MonthNameEnglish] AS [Month Name English]
, [QuarterNameEnglish] AS [Quarter Name English]
, [FiscalMonthOfYear] AS [Fiscal Month Of Year]
, [FiscalQuarter] AS [Fiscal Qtr Of Year]
, [FiscalYear] AS [Fiscal Year]
, [FiscalYearMonth] AS [Fiscal Year Month]
, [FiscalYearQtr] AS [Fiscal Year Qtr]
FROM dbo.DimDate
WHERE FullDate <= EOMONTH(getdate())




GO
/****** Object:  View [dbo].[Driver]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Driver] AS

SELECT [DriverDimKey]		AS [Driver Dim Key]
      ,[ChainNumber]		AS [Chain Number]
      ,[DriverNumber]		AS [Driver Number]
      ,[DriverCode]			AS [Driver Code]
      ,[DriverName]			AS [Driver Name]
	  ,CAST([DriverNumber] as varchar(10)) + ' - ' + [DriverName] AS Driver
      ,[ETLDateInserted]	AS [ETLDateInserted]
  FROM [dbo].[DimDriver]

GO
/****** Object:  View [dbo].[GLDate]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [dbo].[GLDate] AS 
SELECT [DateDimKey] AS [Date Dim Key]
, [FullDate] AS [Full Date]
, [DateName] AS [GL Date]
, [DayOfWeek] AS [Day Of Week]
, [DayNameOfWeek] AS [Day Name Of Week]
, [DayOfMonth] AS [Day Of Month]
, [DayOfYear] AS [Day Of Year]
, [WeekdayWeekend] AS [Weekday Weekend]
, [WeekOfYear] AS [Week Of Year]
, [WeekEndingName] AS [Week Ending Name]
, [MonthName] AS [Month Name]
, [MonthOfYear] AS [Month Of Year]
, [IsLastDayOfMonth] AS [Is Last Day Of Month]
, [CalendarQuarter] AS [Calendar Qtr Of Year]
, [CalendarYear] AS [Calendar Year]
, [CalendarYearMonth] AS [Calendar Year Month]
, [CalendarYearQtr] AS [Calendar Year Qtr]
, [MonthNameEnglish] AS [Month Name English]
, [QuarterNameEnglish] AS [Quarter Name English]
, [FiscalMonthOfYear] AS [Fiscal Month Of Year]
, [FiscalQuarter] AS [Fiscal Qtr Of Year]
, [FiscalYear] AS [Fiscal Year]
, [FiscalYearMonth] AS [Fiscal Year Month]
, [FiscalYearQtr] AS [Fiscal Year Qtr]
FROM dbo.DimDate
WHERE FullDate <= EOMONTH(getdate())





GO
/****** Object:  View [dbo].[Item]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Item] AS 

SELECT [ItemDimKey]				AS [Item Dim Key]
      ,[IMITM]					AS [IMITM]
      ,[ItemNumber]				AS [Item Number]
      ,[ItemDesc]				AS [Item Desc]
	  ,[ItemNumber] + ' - ' + [ItemDesc] AS [ItemNumber Desc]
      ,[UPC]					AS [UPC]
      ,[BrandCode]				AS [Brand Code]
      ,[BrandName]				AS [Brand Name]
      ,[CategoryCode]			AS [Category Code]
      ,[CategoryName]			AS [Category Name]
      ,[PointsFactor]			AS [Points Factor]
      ,[CaseFactor]				AS [Case Factor]
      ,[GrossLBFactor]			AS [Gross LB Factor]
      ,[PalletFactor]			AS [Pallet Factor]
      ,[PCAT2Code]				AS [PCAT2 Code]
      ,[PCAT2]					AS [PCAT2]
      ,[SubBrand]				AS [Sub Brand]
      ,[ProductClass]			AS [Product Class]
      ,[Sub-CategoryName]		AS [Sub-Category Name]
      ,[SegmentName]			AS [Segment Name]
      ,[Brand2]					AS [Brand2]
      ,[FatLevel]				AS [Fat Level]
      ,[Style]					AS [Style]
      ,[Flavor]					AS [Flavor]
      ,[PackageType]			AS [Package Type]
      ,[ProductSizeByOunce]		AS [Product Size by Ounce]
      ,[ContainerType]			AS [ContainerType]
      ,[SellingUnits]			AS [Selling Units]
      ,[ManufacturingProcess]	AS [Manufacturing Process]
      ,[Pre-PackagedUnits]		AS [Pre-Packaged Units]
      ,[ProductBrand]			AS [Product Brand]
      ,[ProductOrigin]			AS [Product Origin]
      ,[ETLDateInserted]		AS [ETLDateInserted]
  FROM [dbo].[DimItem]

GO
/****** Object:  View [dbo].[Route]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Route] AS

SELECT [RouteDimKey]			AS [Route Dim Key]
      ,[RouteNumber]			AS [Route Number]
      ,[RouteName]				AS [Route Name]
	  ,[RouteNumber] + ' - ' + [RouteName] AS [Route]
      ,[PrimaryDriverNumber]	AS [Primary Driver Number]
      ,[BusUnitNumber]			AS [Bus Unit Number]
      ,[BusUnitName]			AS [Bus Unit Name]
	  ,CAST([BusUnitNumber] AS varchar(10)) + ' - ' + [BusUnitName] AS [BusinessUnit]
      ,[BusUnitCity]			AS [Bus Unit City]
      ,[BusUnitState]			AS [Bus Unit State]
      ,[DistCenterNumber]		AS [Dist Center Number]
      ,[DistCenterName]			AS [Dist Center Name]
	  ,CAST([DistCenterNumber] AS varchar(10)) + ' - ' + [DistCenterName] AS [Distribution Center]
      ,[DistCenterCity]			AS [Dist Center City]
      ,[DistCenterState]		AS [Dist Center State]
      ,[DistCenterZip]			AS [Dist Center Zip]
      ,[RouteStatus]			AS [Route Status]
      ,[RouteClassCode]			AS [Route Class Code]
      ,[RouteClassDesc]			AS [Route Class Desc]
	  ,CAST([RouteClassCode] AS varchar(10)) + ' - ' + [RouteClassDesc] AS [RouteType]
      ,[SrcUpdatedBy]			AS [SrcUpdatedBy]
      ,[ScrUpdatedDate]			AS [ScrUpdatedDate]
      ,[ETLDateInserted]		AS [ETLDateInserted]
      ,[SourceSystem]			AS [SourceSystem]
  FROM [dbo].[DimRoute]

GO
/****** Object:  View [dbo].[Sales]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[Sales] AS

SELECT 
	   [SalesNumber]			AS [Sales Number]
      ,[SalesSeq]				AS [Sales Seq]
      ,[SalesDetailTypeCode]	AS [Sales Detail Type Code]
	  ,[SalesTypeCode]			AS [Sales Type Code]
      ,[TicketNumber]			AS [Ticket Number]
      ,[OrderNumber]			AS [Order Number]
      ,[OrderType]				AS [Order Type]
      ,[SalesDeliveryDate]		AS [Sales Delivery Date]
      ,[GLDate]					AS [GL Date]
      ,[LoadDate]				AS [Load Date]
      ,[CustomerDimKey]			AS [Customer Dim Key]
      ,[ItemDimKey]				AS [Item Dim Key]
      ,[DriverDimKey]			AS [Driver Dim Key]
      ,[CreditReasonDimKey]		AS [Credit Reason Dim Key]
      ,[RouteDimKey]			AS [Route Dim Key]
      ,[SubRouteDimKey]			AS [Sub Route Dim Key]
      ,[Units]					AS [Units]
      ,[UnitPrice]				AS [Unit Price]
      ,[SalesAmount]			AS [Sales Amount]
      ,[DiscountAmount]			AS [Discount Amount]
      ,[UnitDiscount]			AS [Unit Discount] 
      ,[DistCenterNumber]		AS [Dist Center Number]
      ,[PointsFactor]			AS [Points Factor]
      ,[CaseFactor]				AS [Case Factor]
      ,[UnitCost]				AS [Unit Cost]      
      ,[RebateAmount]			AS [Rebate Amount]

	  ,CONVERT(money, [UnitCost] * [Units]) AS [Cost] -- unit cost x number of units sold
	  ,PointsFactor * [Units] AS [Points] -- number of points x number of units sold
	  ,CASE WHEN SalesDetailTypeCode IN ('1', '2', 'C3', 'CP', 'SO', 'SZ', 'SP', 'SB') and SalesTypeCode IN ('0','2','3') THEN [Units] ELSE 0 END AS [Gross Units]
	  ,CASE WHEN SalesDetailTypeCode IN ('3', 'C6') THEN [Units] * -1 ELSE 0 END AS [Credit Units]
	  ,CASE WHEN SalesDetailTypeCode IN ('1', '2', 'C3', 'CP', 'SO', 'SZ', 'SP', 'SB') and SalesTypeCode IN ('0','2','3') THEN [SalesAmount] ELSE 0 END AS [Gross Dollars]
	  ,CASE WHEN SalesDetailTypeCode IN ('3', 'C6') THEN ([SalesAmount] - [DiscountAmount]) * -1  ELSE 0 END AS [Credit Dollars] 
	  ,CASE WHEN SalesDetailTypeCode IN ('1', '2', 'C3', 'CP', 'SO', 'SZ', 'SP', 'SB') and SalesTypeCode IN ('0','2','3') THEN  PointsFactor * [Units] ELSE 0 END AS [Gross Points]
	  ,CASE WHEN SalesDetailTypeCode IN ('3', 'C6') THEN  (PointsFactor * [Units]) * -1 ELSE 0 END AS [Credit Points]
	  ,CASE WHEN [DiscountAmount] <> 0 THEN  PointsFactor * [Units] ELSE 0 END AS [Off-Invoice Points]
	  ,CASE WHEN [DiscountAmount] <> 0 THEN [Units] ELSE 0 END AS [Off-Invoice Units]
	  ,CASE WHEN CaseFactor <> 0 THEN  Units/CaseFactor ELSE 0 END AS Cases	
	  ,CASE WHEN SalesDetailTypeCode = '1' THEN GrossLB END AS GrossLB 
      ,[ETLDateInserted]		AS [ETLDateInserted]
      ,[SourceSystem]			AS [SourceSystem]
	  ,[SLDCHGDTE]
	  ,[SDUPMJ]
  FROM [dbo].[FactSales]
 



GO
/****** Object:  View [dbo].[Sub Route]    Script Date: 4/18/2017 4:27:19 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Sub Route] AS

SELECT [SubRouteDimKey]		AS [Sub Route Dim Key]
      ,[SubRouteNumber]		AS [Sub Route Number]
      ,[ETLDateInserted]	AS [ETLDateInserted]
  FROM [dbo].[DimSubRoute]

GO
