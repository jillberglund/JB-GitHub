﻿



CREATE VIEW [dbo].[FactSalesJDE]
AS

SELECT D.[OrderNumber] AS [SalesNumber]
      ,D.[LineNumber] AS [SalesSeq]
      ,[OrderDetailType] AS [Sales Detail Type Code]
      ,[ShipTo] AS [CustomerNumber]
      ,NULL AS [ChainNumber]
      ,NULL AS [CustomerSubNumber]
      ,CAST([ShipTo] as varchar(10)) AS [CustomerDimKey]
      ,convert(int, convert(varchar(8), [RequestedDate], 112))  AS [SalesDeliveryDate]
      ,convert(int, convert(varchar(8), [GLDate], 112)) AS [GL Date]
      ,[InvoiceNumber] AS [TicketNumber]
      ,D.[ItemNumber] AS [ItemNumber]
      ,CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END AS [Units]
      ,CASE WHEN [OrderDetailType] IN ('C3', 'CP', 'SO', 'SZ', 'SP', 'SB') THEN CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END ELSE 0 END AS [Gross Units]
      ,CASE WHEN [OrderDetailType] IN ('C6') THEN CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END * -1 ELSE 0 END AS [Credit Units]
      ,D.[UnitPrice] 
      ,[SalesAmount] AS [SalesAmount] -- *** NEED to add Discount Amount back in
      ,CASE WHEN [OrderDetailType] IN ('C3', 'CP', 'SO', 'SZ', 'SP', 'SB') THEN SalesAmount ELSE 0 END AS [Gross Dollars] -- *** NEED to add Discount Amount
      ,CASE WHEN [OrderDetailType] IN ('C6') THEN SalesAmount *-1 ELSE 0 END AS [Credit Dollars]
	  , CASE WHEN ALABAS = 'N' THEN (SDD.UnitPrice/1000) * CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END ELSE NULL END AS DiscountAmount
	  , CASE WHEN ALABAS = 'N' THEN (SDD.UnitPrice/1000) ELSE NULL END AS UnitDiscount
      ,D.[OrderNumber] AS [OrderNumber]
      ,[OrderDetailType]
      ,convert(int, convert(varchar(8), [LoadDate], 112)) AS [LoadDate]
	  ,convert(int, convert(varchar(8), OrderDate, 112)) AS OrderDate
      ,NULL AS [DriverNumber]
      ,LTRIM(RTRIM([RouteCode])) AS [RouteNumber]
      ,NULL AS [SubRouteNumber]
      ,LTRIM(RTRIM([BusinessUnit])) AS [DistCenterNumber]
      ,IM.PointsFactor AS [Points] 
      ,[UnitCost] AS [ItemCost]
      ,[UnitCost] * [QuantityShipped] AS [ItemCostUnits]
      ,IM.PointsFactor * D.[QuantityShipped] AS PointsUnits
	  ,CASE WHEN [OrderDetailType] IN ('C3', 'CP', 'SO', 'SZ', 'SP', 'SB') THEN IM.PointsFactor * CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END ELSE 0 END AS [Gross Points]
	  ,CASE WHEN [OrderDetailType] IN ('C6') THEN (IM.PointsFactor * CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END) * -1 ELSE 0 END AS [Credit Points] 
	  ,CASE WHEN SDD.UnitPrice <> 0 THEN IM.PointsFactor * CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END ELSE 0 END AS [Off-Invoice Points]
	  ,CASE WHEN SDD.UnitPrice <> 0 THEN CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END ELSE 0 END AS [Off-Invoice Units]
      ,CASE WHEN IM.CaseFactor <> 0 THEN CONVERT(decimal(12,2), CASE WHEN [UnitOfMeasure] = 'CS' THEN [QuantityShipped] * IM.CaseFactor ELSE [QuantityShipped] END/IM.CaseFactor) ELSE 0 END AS Cases
      ,CASE WHEN [OrderDetailType] IN ('C6') THEN '4' ELSE '0' END AS [CreditReasonCode]
      ,NULL AS [GrossLB]
	  ,QuantityShipped
	  ,[UnitOfMeasure]
	  ,'JDE' AS SourceSystem
  FROM [JDE].[SalesDetail] D
  INNER JOIN [JDE].[ItemMaster] IM ON IM.ItemNumber = D.[ItemNumber]
  LEFT JOIN [JDE].[SalesDetailDiscount] SDD 
		ON  SDD.[OrderNumber] = D.[OrderNumber]
		AND SDD.[OrderType] = D.OrderDetailType
		AND SDD.[LineNumber] = D.LineNumber
		AND ALABAS = 'N'		
  WHERE [OrderDetailType] IN ('SO', 'SZ', 'SP', 'SB', 'SA', 'SN', 'SM', 'SF', 'SQ', 'SU', 'C3', 'C6', 'CP', 'FB') 
  AND GLDate >= '2015-01-01'
  --AND [RequestedDate] <=  EOMONTH(getdate())