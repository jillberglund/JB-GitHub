﻿
CREATE VIEW [dbo].[FactSalesERMS]
AS

SELECT 
	 D.[SalesNumber]
	,D.[SalesSeq]
	,CAST(D.SalesDetailTypeCode as nvarchar(2)) AS [Sales Detail Type Code]
	,D.SalesTypeCode
	,D.CustomerNumber
	,D.ChainNumber
	,D.CustomerSubNumber
	--,D.[CustomerDimKey]
	,D.[SalesDeliveryDate]
	,H.[GLDate]
	,D.[TicketNumber]
	,D.[ItemNumber]
	,D.[Units]
	,CASE WHEN D.SalesDetailTypeCode IN (1, 2) and D.SalesTypeCode IN (0,2,3) THEN D.[Units] ELSE 0 END AS [Gross Units]
	,CASE WHEN D.SalesDetailTypeCode = 3 THEN D.[Units] * -1 ELSE 0 END AS [Credit Units]
	,D.[UnitPrice]
	,D.[SalesAmount]
	,CASE WHEN D.SalesDetailTypeCode IN (1, 2) and D.SalesTypeCode IN (0,2,3) THEN D.[SalesAmount] ELSE 0 END AS [Gross Dollars] 
	,CASE WHEN D.SalesDetailTypeCode = 3 THEN (D.[SalesAmount] - D.[DiscountAmount]) * -1  ELSE 0 END AS [Credit Dollars] 
	--,D.[SalesTranDate]
	--,D.[OrderQuantity]
	,D.[DiscountAmount]
	,D.[UnitDiscount]
	,H.OrderNumber
	,CAST(H.OrderType as nvarchar(2)) AS OrderType
	,H.LoadDate
	,H.DriverNumber
	,H.RouteNumber
	,H.SubRouteNumber
	,H.DistCenterNumber 
	,IM.PointsFactor AS Points
	,ISC.ItemCost AS ItemCost
	,ISC.ItemCost * D.[Units] AS ItemCostUnits -- item cost x number of units sold
	,IM.PointsFactor * D.[Units] AS PointsUnits -- number of points x number of units sold
	,CASE WHEN D.SalesDetailTypeCode IN (1, 2) THEN IM.PointsFactor * D.[Units] ELSE 0 END AS [Gross Points]
	,CASE WHEN D.SalesDetailTypeCode = 3 THEN (IM.PointsFactor * D.[Units]) * -1 ELSE 0 END AS [Credit Points]
	,CASE WHEN D.[DiscountAmount] <> 0 THEN IM.PointsFactor * D.[Units] ELSE 0 END AS [Off-Invoice Points]
	,CASE WHEN D.[DiscountAmount] <> 0 THEN D.[Units] ELSE 0 END AS [Off-Invoice Units]
	--,CASE WHEN CF.CaseFactor <> 0 THEN D.Units/CF.CaseFactor ELSE 0 END AS Cases
	,CASE WHEN IM.CaseFactor <> 0 THEN CONVERT(decimal(12,2), D.Units/IM.CaseFactor) ELSE 0 END AS Cases
	,ltrim(rtrim(D.CreditReasonCode)) AS CreditReasonCode
	,CASE WHEN D.SalesDetailTypeCode = 1 THEN D.GrossLB END AS GrossLB
	,'ERMS' AS SourceSystem
	,R.RebateAmount
FROM ERMS.SalesDetail D
LEFT JOIN ERMS.SalesHeader H ON D.SalesNumber = H.SalesNumber
LEFT JOIN [JDE].[ItemMaster] IM ON D.ItemNumber = IM.ItemNumber
LEFT JOIN 
	(SELECT *, row_number() OVER(PARTITION BY x.ItemNumber,x.[MCTPLTNUM], x.EffDate_BOM_int ORDER BY x.[MCTEFFDTE] desc) AS rownum
	 FROM stage.[ItemStandardCost] x) ISC 
	ON ISC.ItemNumber = D.ItemNumber
	AND D.SalesDeliveryDate BETWEEN ISC.EffDate_BOM_int AND ISC.EffDate_EOM_int
	AND H.DistCenterNumber = ISC.[MCTPLTNUM] -- *** Have to add DC in order to avoid dupes
	AND rownum = 1
--LEFT JOIN [dbo].[CaseFactor] CF ON CF.ItemNumber = D.ItemNumber
--	AND CF.DistCenterNumber = H.DistCenterNumber -- *** Have to add DC in order to avoid dupes
--LEFT JOIN [ERMS].[RMCODP] CreditReason ON CreditReason.CODCODNUM = D.SalesReasonCode AND CreditReason.CODCODTYP = 'RC' -- CR=Reason Code
LEFT JOIN [ERMS].[SalesRebate] R ON R.SalesNumber = D.SalesNumber
		AND R.ItemNumber = IM.ItemNumber
		AND R.ChainNumber = D.ChainNumber
		AND R.CustomerNumber = D.CustomerNumber
WHERE H.[GLDate] >= 20150101
--AND [SalesDeliveryDate] <= convert(int, convert(varchar(8), EOMONTH(getdate()), 112)) 