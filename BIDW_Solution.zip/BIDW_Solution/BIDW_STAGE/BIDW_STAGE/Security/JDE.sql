﻿CREATE SCHEMA [JDE]
    AUTHORIZATION [dbo];





