﻿CREATE SCHEMA [stage]
    AUTHORIZATION [dbo];

