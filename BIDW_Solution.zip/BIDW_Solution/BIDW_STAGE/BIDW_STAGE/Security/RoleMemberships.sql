﻿ALTER ROLE [db_owner] ADD MEMBER [DFANOC\dw_db];

