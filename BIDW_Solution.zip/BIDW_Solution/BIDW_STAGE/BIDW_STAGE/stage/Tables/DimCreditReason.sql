﻿CREATE TABLE [stage].[DimCreditReason] (
    [CreditReasonDimKey]      INT           IDENTITY (1, 1) NOT NULL,
    [CreditReasonCode]        NVARCHAR (10) NULL,
    [CreditReasonType]        NVARCHAR (10) NULL,
    [CreditReasonDescription] NVARCHAR (50) NULL,
    [InsertAuditKey]          INT           NULL,
    [UpdateAuditKey]          INT           NULL,
    [ETLDateInserted]         DATETIME2 (7) CONSTRAINT [DF_dbo_CreditReason_ETLDateInserted] DEFAULT (sysutcdatetime()) NULL,
    CONSTRAINT [PK_dbo_CreditReason] PRIMARY KEY CLUSTERED ([CreditReasonDimKey] ASC)
);

