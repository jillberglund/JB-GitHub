﻿CREATE TABLE [stage].[ItemStandardCost] (
    [MCTPLTNUM]       DECIMAL (3)     NOT NULL,
    [ItemNumber]      VARCHAR (20)    NULL,
    [MCTCSTTYP]       INT             NOT NULL,
    [MCTEFFDTE]       INT             NOT NULL,
    [EffDate]         DATE            NULL,
    [EffDate_BOM]     DATE            NULL,
    [EffDate_BOM_int] INT             NULL,
    [DenseRank]       INT             NULL,
    [ItemCost]        DECIMAL (15, 5) NOT NULL,
    [EffDate_EOM]     DATE            NULL,
    [EffDate_EOM_int] INT             NULL,
    [ETLDateInserted] DATETIME2 (0)   CONSTRAINT [DF_stage_ItemStandardCost_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL
);


GO
CREATE NONCLUSTERED INDEX [IX_stage_EffDate_EOM_int]
    ON [stage].[ItemStandardCost]([EffDate_EOM_int] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_stage_MCTPLTNUM]
    ON [stage].[ItemStandardCost]([MCTPLTNUM] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_stage_EffDate_BOM_int]
    ON [stage].[ItemStandardCost]([EffDate_BOM_int] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_stage_IMCTPLTNUM]
    ON [stage].[ItemStandardCost]([MCTPLTNUM] ASC);


GO
CREATE CLUSTERED INDEX [IX_stage_ItemStandardCost]
    ON [stage].[ItemStandardCost]([ItemNumber] ASC);

