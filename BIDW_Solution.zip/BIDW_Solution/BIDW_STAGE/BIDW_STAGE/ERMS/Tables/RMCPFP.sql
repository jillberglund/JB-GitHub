﻿CREATE TABLE [ERMS].[RMCPFP] (
    [CPFCUSCHN]       DECIMAL (5)   NOT NULL,
    [CPFCUSNUM]       DECIMAL (9)   NOT NULL,
    [CPFSUBCUS]       DECIMAL (3)   NOT NULL,
    [CPFCUSHDQ]       CHAR (3)      NOT NULL,
    [CPFCUSRTG]       CHAR (3)      NOT NULL,
    [CPFCUSOWN]       CHAR (3)      NOT NULL,
    [CPFCUSBAN]       CHAR (3)      NOT NULL,
    [CPFCUSCTC]       CHAR (3)      NOT NULL,
    [CPFCRTUSR]       CHAR (10)     NOT NULL,
    [CPFCRTDTE]       DECIMAL (8)   NOT NULL,
    [CPFCRTTIM]       DECIMAL (6)   NOT NULL,
    [CPFCHGUSR]       CHAR (10)     NOT NULL,
    [CPFCHGDTE]       DECIMAL (8)   NOT NULL,
    [CPFCHGTIM]       DECIMAL (6)   NOT NULL,
    [@@UPID]          DECIMAL (7)   NOT NULL,
    [@@RRNO]          DECIMAL (15)  NOT NULL,
    [ETLDateInserted] DATETIME2 (0) CONSTRAINT [DF_ERMS_RMCPFP_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL,
    PRIMARY KEY CLUSTERED ([CPFCUSCHN] ASC, [CPFCUSNUM] ASC, [CPFSUBCUS] ASC)
);

