﻿CREATE TABLE [ERMS].[RMMCTP] (
    [MCTPLTNUM]       DECIMAL (3)     NOT NULL,
    [MCTITMNUM]       CHAR (9)        NOT NULL,
    [MCTCSTTYP]       DECIMAL (2)     NOT NULL,
    [MCTEFFDTE]       DECIMAL (8)     NOT NULL,
    [MCTCSTAMT]       DECIMAL (15, 5) NOT NULL,
    [MCTCRTUSR]       CHAR (10)       NOT NULL,
    [MCTCRTDTE]       DECIMAL (8)     NOT NULL,
    [MCTCRTTIM]       DECIMAL (6)     NOT NULL,
    [MCTCHGUSR]       CHAR (10)       NOT NULL,
    [MCTCHGDTE]       DECIMAL (8)     NOT NULL,
    [MCTCHGTIM]       DECIMAL (6)     NOT NULL,
    [X_UPID]          DECIMAL (7)     NOT NULL,
    [X_RRNO]          DECIMAL (15)    NOT NULL,
    [ETLDateInserted] DATETIME2 (0)   CONSTRAINT [DF_ERMS_RMMCTP_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL,
    PRIMARY KEY CLUSTERED ([MCTPLTNUM] ASC, [MCTITMNUM] ASC, [MCTCSTTYP] ASC, [MCTEFFDTE] ASC)
);

