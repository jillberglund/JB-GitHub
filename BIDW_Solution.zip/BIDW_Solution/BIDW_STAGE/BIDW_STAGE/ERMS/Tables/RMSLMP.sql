﻿CREATE TABLE [ERMS].[RMSLMP] (
    [SLMSLSREP]       DECIMAL (3)   NOT NULL,
    [SLMADRNAM]       CHAR (30)     NOT NULL,
    [SLMADRLN1]       CHAR (30)     NOT NULL,
    [SLMADRLN2]       CHAR (30)     NOT NULL,
    [SLMADRCTY]       CHAR (20)     NOT NULL,
    [SLMADRSTA]       CHAR (3)      NOT NULL,
    [SLMADRZIP]       CHAR (10)     NOT NULL,
    [SLMPHNNUM]       CHAR (20)     NOT NULL,
    [SLMSOCSEC]       CHAR (11)     NOT NULL,
    [SLMCRTUSR]       CHAR (10)     NOT NULL,
    [SLMCRTDTE]       DECIMAL (8)   NOT NULL,
    [SLMCRTTIM]       DECIMAL (6)   NOT NULL,
    [SLMCHGUSR]       CHAR (10)     NOT NULL,
    [SLMCHGDTE]       DECIMAL (8)   NOT NULL,
    [SLMCHGTIM]       DECIMAL (6)   NOT NULL,
    [X_UPID]          DECIMAL (7)   NOT NULL,
    [X_RRNO]          DECIMAL (15)  NOT NULL,
    [ETLDateInserted] DATETIME2 (0) CONSTRAINT [DF_ERMS_RMSLMP_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL,
    PRIMARY KEY CLUSTERED ([SLMSLSREP] ASC)
);

