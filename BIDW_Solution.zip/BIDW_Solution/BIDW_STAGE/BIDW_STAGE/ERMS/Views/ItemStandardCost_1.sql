﻿



CREATE VIEW ERMS.[ItemStandardCost] AS
SELECT --top 100000 
	   [MCTPLTNUM]
      ,LTRIM(RTRIM(COST.[MCTITMNUM])) AS ItemNumber
      ,[MCTCSTTYP]
      ,[MCTEFFDTE]
	  ,CAST(CAST([MCTEFFDTE] AS char(8)) as date) AS EffDate
	  ,DATEFROMPARTS(YEAR(CAST(CAST([MCTEFFDTE] AS char(8)) as date)),MONTH(CAST(CAST([MCTEFFDTE] AS char(8)) as date)),1) AS EffDate_BOM	  
	  ,convert(int, convert(varchar(8), DATEFROMPARTS(YEAR(CAST(CAST([MCTEFFDTE] AS char(8)) as date)),MONTH(CAST(CAST([MCTEFFDTE] AS char(8)) as date)),1), 112)) AS EffDate_BOM_int
	  --,EOMONTH(CAST(CAST([MCTEFFDTE] AS char(8)) as date)) AS EffDate_EOM
	  ,DENSE_RANK() OVER(ORDER BY LEFT([MCTEFFDTE], 6)) AS [DenseRank]
	  --,LEAD([MCTEFFDTE], 1) OVER (ORDER BY LEFT([MCTEFFDTE], 6)) AS nextNbr
      ,[MCTCSTAMT] AS ItemCost	  
	  ,D.nextNbr AS EffDate_EOM
	  ,convert(int, convert(varchar(8), D.nextNbr, 112)) AS EffDate_EOM_int
	  --,LEAD(D.EffDate_BOM, 1) OVER (ORDER BY D.[DenseRank]) AS nextNbr
  FROM [ERMS].[RMMCTP] COST
  LEFT JOIN
		(
		SELECT T.ItemNumber 
		, T.EffDate_BOM
		, T.[DenseRank]
		,ISNULL(DATEADD(day, -1, LEAD(T.EffDate_BOM, 1) OVER (PARTITION BY T.ItemNumber ORDER BY T.[DenseRank])), '9999-12-31') AS nextNbr
		FROM
		(
		SELECT DISTINCT 
			  --[MCTEFFDTE]
			  --,CAST(CAST([MCTEFFDTE] AS char(8)) as date) AS EffDate
			  LTRIM(RTRIM(c1.[MCTITMNUM])) AS ItemNumber
			  ,DATEFROMPARTS(YEAR(CAST(CAST(c1.[MCTEFFDTE] AS char(8)) as date)),MONTH(CAST(CAST(c1.[MCTEFFDTE] AS char(8)) as date)),1) AS EffDate_BOM
			  --,EOMONTH(CAST(CAST([MCTEFFDTE] AS char(8)) as date)) AS EffDate_EOM
			  ,DENSE_RANK() OVER(PARTITION BY c1.[MCTITMNUM] ORDER BY LEFT(c1.[MCTEFFDTE], 6)) AS [DenseRank]
			 -- ,LEAD([MCTEFFDTE], 1) OVER (ORDER BY LEFT([MCTEFFDTE], 6)) AS nextNbr
      
		  FROM [ERMS].[RMMCTP] c1
		  WHERE c1.MCTEFFDTE > 0
		  --AND [MCTITMNUM] = 300
		  ) T
	  ) D ON LTRIM(RTRIM(D.ItemNumber)) = LTRIM(RTRIM(COST.MCTITMNUM)) 
		AND D.EffDate_BOM = DATEFROMPARTS(YEAR(CAST(CAST(COST.[MCTEFFDTE] AS char(8)) as date)),MONTH(CAST(CAST(COST.[MCTEFFDTE] AS char(8)) as date)),1)
		
  WHERE MCTEFFDTE > 0