﻿

CREATE VIEW [ERMS].[CaseFactor]
AS
SELECT [DCIDSTCTR] AS DistCenterNumber
      ,LTRIM(RTRIM([DCIITMNUM])) AS ItemNumber
      ,[DCICASFAC] AS CaseFactor    
      ,[DCICRTUSR]
      ,[DCICRTDTE]
      ,[DCICRTTIM]
      ,[DCICHGUSR]
      ,[DCICHGDTE]
      ,[DCICHGTIM]
      ,[X_UPID]
      ,[X_RRNO]
  FROM [ERMS].[RMDCIP]