﻿





CREATE VIEW [ERMS].[RouteMaster] AS

SELECT  CONVERT(varchar(10) ,[RTERTENUM]) AS RouteNumber
      ,CONVERT(nvarchar(30), [RTELNGDES]) AS RouteName
	  --,CAST([RTERTENUM] AS varchar(10)) + ' - ' + [RTELNGDES] AS [Route]
      ,[RTEDRVNUM] AS PrimaryDriverNumber
      --,[RTELODSEC]
      --,[RTELODSEQ]
      ,[RTECOMNUM] AS BusUnitNumber
	  ,CONVERT(nvarchar(50), COMP.COMADRNAM) AS BusUnitName
	  --,CAST([RTECOMNUM] AS varchar(10)) + ' - ' + COMP.COMADRNAM AS [BusinessUnit]
	  ,CONVERT(nvarchar(50), COMP.COMADRCTY) AS BusUnitCity
	  ,CONVERT(nvarchar(3), COMP.COMADRSTA) AS BusUnitState
      ,[RTEDSTCTR] AS DistCenterNumber
	  ,CONVERT(nvarchar(30), DistCenter.DCNADRNAM) AS DistCenterName
	  --,CAST([RTEDSTCTR] AS varchar(10)) + ' - ' + DistCenter.DCNADRNAM AS [DistributionCenter]
	  ,CONVERT(nvarchar(30), DistCenter.DCNADRCTY)	AS DistCenterCity
	  ,CONVERT(nvarchar(3), DistCenter.DCNADRSTA)	AS DistCenterState
	  ,CONVERT(nvarchar(10), DistCenter.DCNADRZIP)	AS DistCenterZip
      ,CASE WHEN [RTESTACUR] = 1 THEN N'Inactive' ELSE N'Active' END AS [Route Status]
      ,[RTERTECLS] AS RouteClassCode
	  ,CONVERT(nvarchar(30), CLASS.[CODLNGDES]) AS RouteClassDesc
	  --,CAST([RTERTECLS] AS varchar(10)) + ' - ' + CLASS.[CODLNGDES] AS [RouteType]
      ,CONVERT(nvarchar(10), [RTECRTUSR]) AS [RTECRTUSR]
      ,[RTECRTDTE]
      ,[RTECRTTIM]
      ,CONVERT(nvarchar(10), [RTECHGUSR]) AS [SrcUpdatedBy]
      ,[RTECHGDTE] AS [ScrUpdatedDate]
      ,[RTECHGTIM]	
	  ,'ERMS' AS SourceSystem  
  FROM [ERMS].[RMRTEP] RTMaster
  LEFT JOIN [ERMS].RMCOMP AS COMP ON RTMaster.[RTECOMNUM] = COMP.COMCOMNUM
  LEFT JOIN ERMS.RMDCNP DistCenter ON DistCenter.[DCNDSTCTR] = RTMaster.[RTEDSTCTR]
  LEFT JOIN ERMS.RMCODP CLASS ON CLASS.CODCODNUM = RTMaster.[RTERTECLS] AND CLASS.CODCODTYP = 'RL' -- RL=RouteClass 