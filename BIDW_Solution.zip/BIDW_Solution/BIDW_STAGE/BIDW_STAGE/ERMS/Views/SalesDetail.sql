﻿















CREATE view [ERMS].[SalesDetail]

AS

SELECT [SLDSLSNBR] AS SalesNumber
      ,[SLDSLSSEQ] AS SalesSeq
      ,[SLDDTLTYP] AS SalesDetailTypeCode
      ,[SLDCUSCHN] AS ChainNumber
      ,[SLDCUSNUM] AS CustomerNumber
      ,[SLDSUBCUS] AS CustomerSubNumber
      ,[SLDDELDTE] AS SalesDeliveryDate
      ,[SLDTCKNUM] AS TicketNumber
      ,LTRIM(RTRIM([SLDITMNUM])) AS ItemNumber
      ,[SLDSLSTYP] AS SalesTypeCode
      ,[SLDTRNQTY] AS Units
      ,[SLDTRNPRC] AS UnitPrice
      ,[SLDTRNAMT] AS SalesAmount
      --,[SLDTRNDTE] AS SalesTranDate
      --,[SLDORDQTY] AS OrderQuantity
      ,[SLDDSCAMT] AS DiscountAmount
      ,[SLDUNTDSC] AS UnitDiscount
      ,[SLDWGTQTY] AS [GrossLB]
      ,[SLDCASCOM]
      ,[SLDBKRCMM]
      ,[SLDBUYDIS]
      ,[SLDFRTCHG]
      ,[SLDRETDIS]
      ,[SLDIVCDSC]
      ,[SLDARRDSC]
      ,[SLDPRCOVR]
      ,[SLDPRCSRC]
      ,[SLDPRCGRP] AS PriceGroup
      ,[SLDROYCHG]
      ,[SLDADVCHG]
      ,[SLDBASPRC]
      ,[SLDTAXAMT]
      ,[SLDCOMTBL]
      ,[SLDDSCUNT]
      ,[SLDRESCOD] AS CreditReasonCode
      ,[SLDSHPQTY]
      ,[SLDTAXOVR]
      ,[SLDPRCGP1]
      ,[SLDPRCGP2]
      ,[SLDPRCCHN]
      ,[SLDPRCCUS]
      ,[SLDINTSLS]
      ,[SLDUSRSLS]
      ,[SLDCHGUSR]
      ,[SLDCHGDTE] 
      ,[SLDCHGTIM]
      ,[SLDCRTUSR]
      ,[SLDCRTDTE]
      ,[SLDCRTTIM]
      ,[X_UPID]
      ,[X_RRNO]
  FROM [ERMS].[RMSLDP] AS SalesDetail
  --WHERE [SLDDTLTYP] IN (1, 2, 3)