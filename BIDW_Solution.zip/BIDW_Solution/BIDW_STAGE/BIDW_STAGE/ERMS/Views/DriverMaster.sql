﻿

CREATE VIEW [ERMS].[DriverMaster]
AS

SELECT [ChainNumber]
,[CustomerNumber] AS DriverNumber
,[SubCustomerNumber]
,[CustomerCode] AS DriverCode
,[CustomerName] AS DriverName
--,CAST([CustomerNumber] as varchar(10)) + ' - ' + [CustomerName] AS Driver
FROM [ERMS].[CustomerMaster]
WHERe ChainNumber = 99999