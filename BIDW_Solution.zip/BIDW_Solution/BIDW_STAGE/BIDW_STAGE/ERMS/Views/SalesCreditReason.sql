﻿








CREATE VIEW [ERMS].[SalesCreditReason] AS

select   CAST(ltrim(rtrim([CODCODNUM])) as nvarchar(10))   AS CreditReasonCode
		,CAST(CODCODTYP	as nvarchar(10))   AS CreditReasonType
		,CAST([CODLNGDES] as nvarchar(30)) AS CreditReasonDescription
		,HASHBYTES('SHA1',
					  CAST(ltrim(rtrim([CODCODNUM])) as nvarchar(10))
					+ CAST(CODCODTYP as nvarchar(10)) 
					+ CAST([CODLNGDES] as nvarchar(30)) 
					) AS HASH_DIFF
from [ERMS].[RMCODP]
where CODCODTYP = 'RC' 
UNION
SELECT N'0', N'RC', N'N/A', HASHBYTES('SHA1', N'0' + N'RC' + N'N/A') AS HASH_DIFF
UNION
SELECT N'999', N'RC', N'', HASHBYTES('SHA1', N'999' + N'RC' + N'') AS HASH_DIFF