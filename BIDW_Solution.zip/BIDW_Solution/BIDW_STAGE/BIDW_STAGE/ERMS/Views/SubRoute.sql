﻿








CREATE VIEW [ERMS].[SubRoute] AS

select  DISTINCT CONVERT(int, SubRouteNumber) AS SubRouteNumber
FROM [ERMS].[SalesHeader]