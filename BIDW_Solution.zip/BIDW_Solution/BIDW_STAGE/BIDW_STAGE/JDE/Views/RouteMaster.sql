﻿





CREATE VIEW [JDE].[RouteMaster] AS



  SELECT CONVERT(varchar(10), LTRIM(RTRIM([DRKY]))) AS [RouteNumber]
      ,CONVERT(nvarchar(30), [DRDL01]) AS [RouteName]
      --,LTRIM(RTRIM([DRKY])) +' - ' + [DRDL01] AS [Route]
      ,NULL AS [PrimaryDriverNumber]
      ,NULL AS [BusUnitNumber]
      ,NULL AS [BusUnitName]
      ,NULL AS [BusinessUnit]
      ,NULL AS [BusUnitCity]
      ,NULL AS [BusUnitState]
      ,NULL AS [DistCenterNumber]
      ,NULL AS [DistCenterName]
      ,NULL AS [DistributionCenter]
      ,NULL AS [DistCenterCity]
      ,NULL AS [DistCenterState]
      ,NULL AS [DistCenterZip]
      ,NULL AS [Route Status]
      ,NULL AS [RouteClassCode]
      ,NULL AS [RouteClassDesc]
      ,NULL AS [RouteType]
      ,NULL AS [RTECRTUSR]
      ,NULL AS [RTECRTDTE]
      ,NULL AS [RTECRTTIM]
      ,NULL AS [SrcUpdatedBy]
      ,NULL AS [ScrUpdatedDate]
      ,NULL AS [RTECHGTIM]
	  ,'JDE' AS SourceSystem
FROM [JDE].[F0005]
WHERE [DRSY] = 42 AND DRRT = 'RT'