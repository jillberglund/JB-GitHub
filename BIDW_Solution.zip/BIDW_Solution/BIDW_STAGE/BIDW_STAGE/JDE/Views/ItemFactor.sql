﻿


CREATE VIEW [JDE].[ItemFactor] 

AS

SELECT    [UMITM]
		, [CS]
		, CONVERT(decimal(9,2), [CS]/10000000) AS CaseFactor
		, [LB]
		, CONVERT(decimal(18,5), [LB]/10000000) AS GrossLBFactor
		, [PA]
		, CONVERT(decimal(18,5), 1/([PA]/10000000)) AS PalletFactor
		, [PO]
		, CONVERT(decimal(9,5), 1/([PO]/10000000)) AS PointsFactor
		, [BS]
		, CONVERT(decimal(9,2), [BS]/10000000) AS BossyFactor
		, [TO]
		, [TY]
		, [CA]
FROM
(SELECT [UMITM]
      ,[UMUM]
      ,[UMCONV]
  FROM [JDE].[F41002]
  WHERE 1=1
 --AND [UMITM] = 90
  AND UMUM IN ('PO', 'CS', 'LB', 'PA', 'BS', 'TO', 'TY', 'CA')
  ) AS SourceTable

	PIVOT
		(
		MAX(UMCONV)
		FOR UMUM IN ([CS], [LB], [PA], [PO], [BS], [TO], [TY], [CA])
		) AS PivotTable;