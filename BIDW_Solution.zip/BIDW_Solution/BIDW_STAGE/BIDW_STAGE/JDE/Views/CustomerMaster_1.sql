﻿









CREATE VIEW [JDE].[CustomerMaster] AS



  SELECT  
	   C.ABAN83 AS [ChainNumber]
      ,C.[ABAN8] AS [CustomerNumber]
      ,NULL AS [SubCustomerNumber]
      ,CONVERT(varchar(20), C.[ABAN8]) AS CustomerCode
      ,CONVERT(nvarchar(50), C.[ABALPH]) AS [CustomerName]
      ,NULL AS DistCenterNumber
	  ,CONVERT(varchar(10), ABAC05) AS BusUnitNumber
	  ,CONVERT(nvarchar(50), COMP.COMADRNAM) AS BusUnitName
      ,NULL AS [DefaultRouteNumber]
      ,CAST(C.[ABAC02] as int) AS [SalesRepNumber]
	  ,CONVERT(nvarchar(50), SalesRep.SLMADRNAM) AS SalesRepName
	  ,CONVERT(nvarchar(50), SalesRep.SLMADRLN1) AS SalesRepAddressLine1
	  ,CONVERT(nvarchar(30), SalesRep.SLMADRCTY) AS SalesRepCity
	  ,CONVERT(nvarchar(3), SalesRep.SLMADRSTA) AS SalesRepState
	  ,CONVERT(nvarchar(10), SalesRep.SLMADRZIP) AS SalesRepZip
      ,CONVERT(nvarchar(30), ClassTrade.[CODLNGDES]) AS [ClassOfTrade]
      ,CASE WHEN C.ABAT1 IN ('D', 'CI') THEN 1 ELSE 0 END AS [CustomerInactiveFlag]
	  ,NULL AS [ShipToName]
	  ,NULL AS [ShipToAddressLine1]
	  ,NULL AS [ShipToAddressLine2]
	  ,NULL AS [ShipToCity]
	  ,NULL AS [ShipToState]
	  ,NULL AS [ShipToZip]
      ,NULL AS [BillToName]
      ,NULL AS [BillToAdressLine1]
      ,NULL AS [BillToAddressLine2]
      ,NULL AS [BillToCity]
      ,NULL AS [BillToState]
      ,NULL AS [BillToZip]
      ,NULL AS [CUSCRTUSR]
      ,NULL AS [CUSCRTDTE]
      ,NULL AS [CUSCRTTIM]
      ,CONVERT(nvarchar(10), [ABUSER]) AS [SrcUpdatedBy]
      ,[ABUPMJ] AS [ScrUpdatedDate]
      ,NULL AS [CUSCHGTIM]
 	  ,CONVERT(nvarchar(50), Parent.[CODLNGDES]) AS [Parent]
	  ,CONVERT(nvarchar(50), Division.[CODLNGDES]) AS [Division]
	  ,CONVERT(nvarchar(50), [Owner].[CODLNGDES]) AS [Owner]
	  ,NULL AS [DistributionFormat]	
	  ,NULL AS [TradeChannel]
	  ,0 AS [SpecialBillingCode]
	  ,0 AS SBTCode
	  ,'JDE' AS SourceSystem
FROM [JDE].[F0101JC] C
LEFT JOIN [ERMS].[RMSLMP] SalesRep ON SalesRep.SLMSLSREP = CAST(C.[ABAC02] as int)
LEFT JOIN [ERMS].[RMCODP] ClassTrade ON C.ABAC25 = ClassTrade.CODSHTDES AND ClassTrade.CODCODTYP = 'CT' 
LEFT JOIN [ERMS].[RMCODP] Parent ON Parent.CODCODNUM = C.ABAC22 AND Parent.CODCODTYP = 'HEADQTRS'
LEFT JOIN [ERMS].[RMCODP] Division ON Division.CODCODNUM = C.ABAC30 AND Division.CODCODTYP = 'BANNER' 
LEFT JOIN [ERMS].[RMCODP] [Owner] ON [Owner].CODCODNUM = C.ABAC23 AND [Owner].CODCODTYP = 'OWNER' 
LEFT JOIN [ERMS].RMCOMP AS COMP ON C.ABAC05 = CAST(COMP.COMCOMNUM as varchar(3))