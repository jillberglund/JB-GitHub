﻿








CREATE VIEW [JDE].[ItemMaster] AS

SELECT  ITEM_MASTER.IMITM
		, CONVERT(varchar(20) ,LTRIM(RTRIM(IMLITM))) AS ItemNumber
		--, IMAITM
		,CONVERT(nvarchar(100),  IMDSC1) AS ItemDesc
		,CONVERT(nvarchar(50), IMSRTX) AS IMSRTX
		,CONVERT(nvarchar(50), IMALN) AS IMALN				
		,CONVERT(nvarchar(20), IMUPCN) AS UPC
		,CONVERT(varchar(3) ,LTRIM(RTRIM(BRAND.DRKY))) AS BrandCode
		,CONVERT(nvarchar(50), BRAND.DRDL01) AS BrandName
		,CONVERT(varchar(3) ,LTRIM(RTRIM(CATEGORY.DRKY))) AS CategoryCode
		,CONVERT(nvarchar(50), Category.DRDL01) AS CategoryName
		, F.PointsFactor 
		, F.CaseFactor
		, F.GrossLBFactor
		, F.PalletFactor
		--, LTRIM(RTRIM(IMLITM)) + ' - ' + IMDSC1 AS [ItemNumber Desc]
		,CONVERT(varchar(3) ,LTRIM(RTRIM(PCAT2.DRKY))) AS PCAT2Code
		,CONVERT(nvarchar(50), PCAT2.DRDL01) AS PCAT2
		,CONVERT(nvarchar(50), SUBBRAND.DRDL01) AS [SubBrand]
		,CONVERT(nvarchar(50), ProductClass.DRDL01) AS [ProductClass]
		,CONVERT(nvarchar(50), SubCategory.DRDL01) AS [Sub-CategoryName]
		,CONVERT(nvarchar(50), Segment.DRDL01) AS [SegmentName]
		,CONVERT(nvarchar(50), Brand2.DRDL01) AS Brand2
		,CONVERT(nvarchar(50), FatLevel.DRDL01) AS [FatLevel]
		,CONVERT(nvarchar(50), Style.DRDL01) AS Style
		,CONVERT(nvarchar(50), Flavor.DRDL01) AS Flavor
		,CONVERT(nvarchar(50), PackageType.DRDL01) AS [PackageType]
		,CONVERT(nvarchar(50), ProductSizeOz.DRDL01) AS [ProductSizeByOunce]
		,CONVERT(nvarchar(50), ContainerType.DRDL01) AS [ContainerType]
		,CONVERT(nvarchar(50), SellingUnits.DRDL01)  AS [SellingUnits]
		,CONVERT(nvarchar(50), ManfProcess.DRDL01)   AS [ManufacturingProcess] 
		,CONVERT(nvarchar(50), PrePkgUnits.DRDL01)   AS [Pre-PackagedUnits]
		,CONVERT(nvarchar(50), ProductBrand.DRDL01)  AS [ProductBrand]
		,CONVERT(nvarchar(1), ITEM_MASTER.IMSTKT) AS [ProductOrigin]
  FROM JDE.F4101 ITEM_MASTER

  --join with eRMS item table to get points
  --LEFT JOIN ERMS.RMITMP eRMS_ITEM ON LTRIM(RTRIM(eRMS_ITEM.ITMITMNUM)) = LTRIM(RTRIM(IMLITM))

  -- join with ItemFactor (JDE.F41002) to get factors (units of measure)
  LEFT JOIN [JDE].[ItemFactor] F ON ITEM_MASTER.[IMITM] = F.[UMITM]

  --join with supplemental table F41903
  LEFT JOIN [JDE].[F41903] ITEM_SUPPL
  ON LTRIM(RTRIM(ITEM_MASTER.IMLITM)) = LTRIM(RTRIM(ITEM_SUPPL.QILITM))

  -- join to get brand
  LEFT JOIN  JDE.F0005 BRAND -- JOIN on system (DRSY), type (DRRT) and key (DRKY)
	ON LTRIM(RTRIM(ITEM_MASTER.IMSRP1)) = LTRIM(RTRIM(BRAND.DRKY))  AND BRAND.DRSY = '41' and BRAND.DRRT = 'S1'

  --join to get category
  LEFT JOIN  JDE.F0005 CATEGORY
	ON LTRIM(RTRIM(ITEM_MASTER.IMSRP2)) = LTRIM(RTRIM(CATEGORY.DRKY)) AND CATEGORY.DRSY = '41' and CATEGORY.DRRT = 'S2'

  --join to get PCAT2
  LEFT JOIN  JDE.F0005 PCAT2
	ON LTRIM(RTRIM(ITEM_MASTER.IMGLPT)) = LTRIM(RTRIM(PCAT2.DRKY)) AND PCAT2.DRSY = '41' and PCAT2.DRRT = '9'

  --join to get Sub-Brand
  LEFT JOIN  JDE.F0005 SUBBRAND
	ON LTRIM(RTRIM(ITEM_MASTER.IMSRP1)) = LTRIM(RTRIM(SUBBRAND.DRKY)) AND SUBBRAND.DRSY = '41' and SUBBRAND.DRRT = 'S1'

  --join to get ProductClass
  LEFT JOIN  JDE.F0005 ProductClass
	ON LTRIM(RTRIM(ITEM_MASTER.IMPRP9)) = LTRIM(RTRIM(ProductClass.DRKY)) AND ProductClass.DRSY = '5541' and ProductClass.DRRT = 'PC'

  --join to get SubCategory
  LEFT JOIN  JDE.F0005 SubCategory
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC02)) = LTRIM(RTRIM(SubCategory.DRKY)) AND SubCategory.DRSY = '41' and SubCategory.DRRT = '22'

  --join to get Segment
  LEFT JOIN  JDE.F0005 Segment
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC12)) = LTRIM(RTRIM(Segment.DRKY)) AND Segment.DRSY = '41' and Segment.DRRT = '22'

  --join to get Brand2
  LEFT JOIN  JDE.F0005 Brand2
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC22)) = LTRIM(RTRIM(Brand2.DRKY)) AND Brand2.DRSY = '41' and Brand2.DRRT = '42'

  --join to get FatLevel
  LEFT JOIN  JDE.F0005 FatLevel
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC03)) = LTRIM(RTRIM(FatLevel.DRKY)) AND FatLevel.DRSY = '41' and FatLevel.DRRT = '23'

  --join to get Style
  LEFT JOIN  JDE.F0005 Style
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC14)) = LTRIM(RTRIM(Style.DRKY)) AND Style.DRSY = '41' and Style.DRRT = '34'

  --join to get Flavor
  LEFT JOIN  JDE.F0005 Flavor
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC23)) = LTRIM(RTRIM(Flavor.DRKY)) AND Flavor.DRSY = '41' and Flavor.DRRT = '43'

  --join to get PackageType
  LEFT JOIN  JDE.F0005 PackageType
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC04)) = LTRIM(RTRIM(PackageType.DRKY)) AND PackageType.DRSY = '41' and PackageType.DRRT = '24'

  --join to get ProductSizeOz
  LEFT JOIN  JDE.F0005 ProductSizeOz
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC13)) = LTRIM(RTRIM(ProductSizeOz.DRKY)) AND ProductSizeOz.DRSY = '41' and ProductSizeOz.DRRT = '33'

  --join to get ContainerType
  LEFT JOIN  JDE.F0005 ContainerType
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC24)) = LTRIM(RTRIM(ContainerType.DRKY)) AND ContainerType.DRSY = '41' and ContainerType.DRRT = '44'

  --join to get SellingUnits
  LEFT JOIN  JDE.F0005 SellingUnits
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC25)) = LTRIM(RTRIM(SellingUnits.DRKY)) AND SellingUnits.DRSY = '41' and SellingUnits.DRRT = '45'

  --join to get ManfProcess
  LEFT JOIN  JDE.F0005 ManfProcess
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC15)) = LTRIM(RTRIM(ManfProcess.DRKY)) AND ManfProcess.DRSY = '41' and ManfProcess.DRRT = '35'

  --join to get PrePkgUnits
  LEFT JOIN  JDE.F0005 PrePkgUnits
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC05)) = LTRIM(RTRIM(PrePkgUnits.DRKY)) AND PrePkgUnits.DRSY = '41' and PrePkgUnits.DRRT = '25'

  --join to get ProductBrand
  LEFT JOIN  JDE.F0005 ProductBrand
	ON LTRIM(RTRIM(ITEM_SUPPL.QIC21)) = LTRIM(RTRIM(ProductBrand.DRKY)) AND ProductBrand.DRSY = '41' and ProductBrand.DRRT = '41'