﻿CREATE TABLE [JDE].[F0005] (
    [DRSY]            VARCHAR (4)   NOT NULL,
    [DRRT]            VARCHAR (2)   NOT NULL,
    [DRKY]            VARCHAR (10)  NOT NULL,
    [DRDL01]          VARCHAR (30)  NOT NULL,
    [DRDL02]          VARCHAR (30)  NOT NULL,
    [DRSPHD]          VARCHAR (10)  NOT NULL,
    [DRUDCO]          VARCHAR (1)   NOT NULL,
    [DRHRDC]          VARCHAR (1)   NOT NULL,
    [DRUSER]          VARCHAR (10)  NOT NULL,
    [DRPID]           VARCHAR (10)  NOT NULL,
    [DRUPMJ]          DECIMAL (6)   NOT NULL,
    [DRJOBN]          VARCHAR (10)  NOT NULL,
    [DRUPMT]          DECIMAL (6)   NOT NULL,
    [ETLDateInserted] DATETIME2 (0) CONSTRAINT [DF_JDE_F0005_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL,
    CONSTRAINT [PK_F0005] PRIMARY KEY CLUSTERED ([DRSY] ASC, [DRRT] ASC, [DRKY] ASC)
);



