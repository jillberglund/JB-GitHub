﻿CREATE TABLE [JDE].[F41002] (
    [UMMCU]           VARCHAR (12)  NULL,
    [UMITM]           NUMERIC (8)   NULL,
    [UMUM]            VARCHAR (2)   NULL,
    [UMRUM]           VARCHAR (2)   NULL,
    [UMUSTR]          VARCHAR (1)   NULL,
    [UMCONV]          NUMERIC (15)  NULL,
    [UMCNV1]          NUMERIC (15)  NULL,
    [UMUSER]          VARCHAR (10)  NULL,
    [UMPID]           VARCHAR (10)  NULL,
    [UMJOBN]          VARCHAR (10)  NULL,
    [UMUPMJ]          NUMERIC (6)   NULL,
    [UMTDAY]          NUMERIC (6)   NULL,
    [ETLDateInserted] DATETIME2 (0) CONSTRAINT [DF_JDE_F41002_ETLDateInserted] DEFAULT (sysutcdatetime()) NOT NULL
);


GO
CREATE CLUSTERED INDEX [IX_F41002_UMITM]
    ON [JDE].[F41002]([UMITM] ASC);

