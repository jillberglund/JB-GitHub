﻿CREATE TABLE [dbo].[WindowsEventLogsEventIDComments] (
    [id]      INT           IDENTITY (1, 1) NOT NULL,
    [EventID] INT           NULL,
    [Comment] VARCHAR (MAX) NULL
);

