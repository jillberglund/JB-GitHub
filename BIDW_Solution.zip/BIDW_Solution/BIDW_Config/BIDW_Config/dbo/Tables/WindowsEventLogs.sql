﻿CREATE TABLE [dbo].[WindowsEventLogs] (
    [id]             INT            IDENTITY (1, 1) NOT NULL,
    [EventType]      VARCHAR (1024) NULL,
    [LogType]        VARCHAR (1024) NULL,
    [SourceSystem]   VARCHAR (1024) NULL,
    [ReportedBy]     VARCHAR (1024) NULL,
    [SourceComputer] VARCHAR (1024) NULL,
    [EventID]        VARCHAR (100)  NULL,
    [TaskCategory]   VARCHAR (1024) NULL,
    [Message]        VARCHAR (MAX)  NULL,
    [Include]        BIT            NULL,
    [LogTime]        DATETIME       NULL,
    CONSTRAINT [PK__sysssis__3213E83F758F010A] PRIMARY KEY CLUSTERED ([id] ASC)
);

