﻿CREATE TABLE [dbo].[TraceRT] (
    [ID]        INT          IDENTITY (1, 1) NOT NULL,
    [TimeStamp] DATETIME     NULL,
    [FromIP]    VARCHAR (50) NULL,
    [ToIP]      VARCHAR (50) NULL,
    [HopIP]     VARCHAR (50) NULL,
    [AvgTime]   INT          NULL,
    [HopNo]     INT          NULL
);

