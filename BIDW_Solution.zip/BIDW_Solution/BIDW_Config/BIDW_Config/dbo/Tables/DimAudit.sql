﻿CREATE TABLE [dbo].[DimAudit] (
    [AuditKey]                INT              IDENTITY (1, 1) NOT NULL,
    [ParentAuditKey]          INT              NOT NULL,
    [TableName]               NVARCHAR (200)   CONSTRAINT [DF_DimAudit_TableName] DEFAULT ('Unknown') NOT NULL,
    [PkgName]                 NVARCHAR (500)   CONSTRAINT [DF_DimAudit_PkgNam] DEFAULT ('Unknown') NOT NULL,
    [ExecStartDT]             DATETIME         CONSTRAINT [DF_DimAudit_ExecStartDT] DEFAULT (getdate()) NOT NULL,
    [ExecStopDT]              DATETIME         NULL,
    [ExecDurationMin]         AS               (datediff(minute,[ExecStartDT],[ExecStopDT])),
    [PkgGUID]                 UNIQUEIDENTIFIER NULL,
    [PkgVersionGUID]          UNIQUEIDENTIFIER NULL,
    [PkgVersionMajor]         SMALLINT         NULL,
    [PkgVersionMinor]         SMALLINT         NULL,
    [ExecutionInstanceGUID]   UNIQUEIDENTIFIER NULL,
    [ExtractRowCnt]           BIGINT           NULL,
    [InsertRowCnt]            BIGINT           NULL,
    [UpdateRowCnt]            BIGINT           NULL,
    [ErrorRowCnt]             BIGINT           NULL,
    [TableInitialRowCnt]      BIGINT           NULL,
    [TableFinalRowCnt]        BIGINT           NULL,
    [TableMaxSurrogateKey]    BIGINT           NULL,
    [SuccessfulProcessingInd] NCHAR (1)        CONSTRAINT [DF_DimAudit_SuccessInd] DEFAULT ('N') NOT NULL,
    CONSTRAINT [PK_dbo_DimAudit] PRIMARY KEY CLUSTERED ([AuditKey] ASC)
);

