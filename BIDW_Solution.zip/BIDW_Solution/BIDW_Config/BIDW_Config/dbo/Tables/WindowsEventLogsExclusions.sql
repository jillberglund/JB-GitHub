﻿CREATE TABLE [dbo].[WindowsEventLogsExclusions] (
    [ID]        INT           IDENTITY (1, 1) NOT NULL,
    [ErrorTest] VARCHAR (MAX) NULL
);

